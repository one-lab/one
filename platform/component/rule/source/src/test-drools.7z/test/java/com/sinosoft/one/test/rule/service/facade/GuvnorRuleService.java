package com.sinosoft.one.test.rule.service.facade;

public interface GuvnorRuleService {
	public void executeRule(Object... facts) throws Exception;
}
