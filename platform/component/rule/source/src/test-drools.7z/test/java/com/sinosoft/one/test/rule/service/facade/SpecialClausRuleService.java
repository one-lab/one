package com.sinosoft.one.test.rule.service.facade;

public interface SpecialClausRuleService {

	public void executeRule(Object global, Object... facts) throws Exception;
}
