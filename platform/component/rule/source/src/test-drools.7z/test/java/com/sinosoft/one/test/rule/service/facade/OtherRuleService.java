package com.sinosoft.one.test.rule.service.facade;

public interface OtherRuleService {
	public void executeRule(Object fact) throws Exception;
}
